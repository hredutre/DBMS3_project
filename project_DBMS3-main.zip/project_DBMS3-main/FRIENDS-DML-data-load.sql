 .mode csv books
 .separator ,
 .import books.csv books



 .mode csv user
 .separator ,
 .import user.csv user



 .mode csv location
 .separator ,
 .import location.csv location



 .mode csv rating
 .separator ,
 .import rating.csv rating


 .mode csv login
 .separator ,
 .import login.csv login



 .mode csv book_rec
 .separator ,
 .import book_rec.csv book_rec


